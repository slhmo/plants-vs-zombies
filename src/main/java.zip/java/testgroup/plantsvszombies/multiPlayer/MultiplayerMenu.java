package testgroup.plantsvszombies.multiPlayer;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

import java.net.InetAddress;

public class MultiplayerMenu {
    StackPane root;
    AnchorPane anchorPane;
    ImageView menuImg;
    ImageView createGameImg;
    ImageView joinGameImg;


    public MultiplayerMenu(StackPane root) {
        this.root = root;
        createMenu();
    }

    private void createMenu() {
        anchorPane = new AnchorPane();

        menuImg = new ImageView(getClass().getResource("/multiplayer/Menu.png").toString());
        menuImg.setFitWidth(1920);
        menuImg.setFitHeight(1080);

        createGameImg = new ImageView(getClass().getResource("/multiplayer/CreateGame.png").toString());
        createGameImg.setFitWidth(750);
        createGameImg.setFitHeight(200);
        createGameImg.setX(585);
        createGameImg.setY(440);

        createGameImg.setOnMouseEntered(event -> {
            createGameImg.setOpacity(0.5);
        });

        createGameImg.setOnMouseExited(event -> {
            createGameImg.setOpacity(1);
        });

        createGameImg.setOnMouseClicked(event -> {
            AnchorPane anchorPane1 = new AnchorPane();

            InetAddress serverIP = GetRealIP.getIp();
            assert serverIP != null;
            Label ipAddressLabel = new Label(serverIP.toString());
            ipAddressLabel.setLayoutX(1000);

            PVZServer server = new PVZServer(root, anchorPane1);
            server.start();

            Button playButton = new Button("play");
            playButton.setOnMouseClicked(event1 -> {
                server.startGame();
            });

            root.getChildren().clear();
            anchorPane1.getChildren().addAll(ipAddressLabel, playButton);
            root.getChildren().add(anchorPane1);
        });

        joinGameImg = new ImageView(getClass().getResource("/multiplayer/JoinGame.png").toString());
        joinGameImg.setFitWidth(750);
        joinGameImg.setFitHeight(200);
        joinGameImg.setX(585);
        joinGameImg.setY(640);

        joinGameImg.setOnMouseEntered(event -> {
            joinGameImg.setOpacity(0.5);
        });

        joinGameImg.setOnMouseExited(event -> {
            joinGameImg.setOpacity(1);
        });
        joinGameImg.setOnMouseClicked(event -> {
            TextField ipTextField = new TextField("enter ip here");
            ipTextField.setLayoutX(500);
            Button playButton = new Button("play");
            playButton.setOnMouseClicked(event1 -> {
                String ip = ipTextField.getText();
                PVZClient client = new PVZClient(root, anchorPane, ip);
                client.start();
                client.startGame();
            });
            anchorPane.getChildren().addAll(ipTextField, playButton);
        });

        anchorPane.getChildren().addAll(menuImg, createGameImg, joinGameImg);
        root.getChildren().add(anchorPane);
    }
}
